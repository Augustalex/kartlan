#!/bin/bash
set -e
cd "$(dirname "$0")"
./install.sh "$@"
